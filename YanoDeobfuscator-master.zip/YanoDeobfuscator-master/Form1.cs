﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

namespace YanoDeobfuscator
{
    public partial class Form1 : Form
    {

        #region Declarations
        public string DirectoryName = "";
        public int ConstantKey;
        public int ConstantNum;
        public MethodDef Methoddecryption;
        public TypeDef Typedecryption;
        public MethodDef MethodeResource;
        public TypeDef TypeResource;
        public ModuleDefMD module;
        public int x;
        public int DeobedStringNumber;
        private Assembly _loadedAssembly;
        private readonly Dictionary<MethodDef, MethodInfo> _methodInfoCache = new Dictionary<MethodDef, MethodInfo>();

        #endregion

        #region Designer

        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TextBox1DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void TextBox1DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                Array array = (Array)e.Data.GetData(DataFormats.FileDrop);
                if (array != null)
                {
                    string text = array.GetValue(0).ToString();
                    int num = text.LastIndexOf(".", StringComparison.Ordinal);
                    if (num != -1)
                    {
                        string text2 = text.Substring(num);
                        text2 = text2.ToLower();
                        if (text2 == ".exe" || text2 == ".dll")
                        {
                            Activate();
                            textBox1.Text = text;
                            int num2 = text.LastIndexOf("\\", StringComparison.Ordinal);
                            if (num2 != -1)
                            {
                                DirectoryName = text.Remove(num2, text.Length - num2);
                            }
                            if (DirectoryName.Length == 2)
                            {
                                DirectoryName += "\\";
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                module = ModuleDefMD.Load(textBox1.Text);
                var candidates = FindDecryptorCandidates(module).ToList();
                DeobedStringNumber = 0;
                int passReplaced;
                do
                {
                    passReplaced = DecryptStrings(module, candidates);
                    DeobedStringNumber += passReplaced;
                } while (passReplaced > 0);

                SanitizeIdentifiers(module);
                string text2 = Path.GetDirectoryName(textBox1.Text);
                if (!text2.EndsWith("\\"))
                {
                    text2 += "\\";
                }
                string path = text2 + Path.GetFileNameWithoutExtension(textBox1.Text) + "_patched" +
                              Path.GetExtension(textBox1.Text);
                module.Write(path);
                label2.Text = "Successfully decrypted " + DeobedStringNumber + " strings !";
            }
            catch (Exception ex)
            {
                label2.Text = "Erro: " + ex.Message;
            }
        }

        #endregion

        #region Method

        private void FindStringDecrypterMethods(ModuleDefMD module)
        {
            foreach (var type in module.Types)
            {
                foreach (var method in type.Methods)
                {
                    if (method.HasBody == false)
                        continue;
                    if (method.Body.HasInstructions)
                    {
                        var instrs = method.Body.Instructions;
                        if (instrs.Count > 52)
                        {
                            for (int i = 0; i < instrs.Count - 3; i++)
                            {
                                if (instrs[i].IsLdcI4() && instrs[1].OpCode.Code == Code.Ldarg_1 &&
                                    instrs[2].OpCode.Code == Code.Add && instrs[3].OpCode.Code == Code.Stloc_0 &&
                                    instrs[4].OpCode.Code == Code.Ldarg_0 && instrs[42].OpCode.Code == Code.Or &&
                                    instrs[50].OpCode.Code == Code.Ldloc_1)
                                {
                                    Methoddecryption = method;
                                    Typedecryption = type;
                                    ConstantKey = instrs[i].GetLdcI4Value();
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        private void FindStringDecrypterMethodsWithflow(ModuleDefMD module)
        {
            foreach (var type in module.Types)
            {
                foreach (var method in type.Methods)
                {
                    if (method.HasBody == false)
                        continue;
                    if (method.Body.HasInstructions)
                    {
                        var instrs = method.Body.Instructions;
                        if (instrs.Count > 52)
                        {
                            for (int i = 0; i < instrs.Count - 3; i++)
                            {
                                if (instrs[i].IsLdcI4() && instrs[1].OpCode.Code == Code.Ldarg_1 &&
                                    instrs[2].OpCode.Code == Code.Add && instrs[3].OpCode.Code == Code.Stloc_0 &&
                                    instrs[4].OpCode.Code == Code.Ldc_I4_0 && instrs[42].OpCode.Code == Code.Ldloc_0 &&
                                    instrs[45].OpCode.Code == Code.Add && instrs[56].OpCode.Code == Code.Add)
                                {
                                    Methoddecryption = method;
                                    Typedecryption = type;
                                    ConstantKey = instrs[i].GetLdcI4Value();
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        private IEnumerable<MethodDef> FindDecryptorCandidates(ModuleDefMD module)
        {
            foreach (var type in module.GetTypes())
            {
                foreach (var method in type.Methods)
                {
                    if (!method.HasBody)
                        continue;
                    if (!method.IsStatic)
                        continue;
                    if (!method.MethodSig.RetType.FullName.Equals("System.String"))
                        continue;
                    if (method.Parameters.Count != 2)
                        continue;
                    var p0 = method.Parameters[0].Type.FullName;
                    var p1 = method.Parameters[1].Type.FullName;
                    bool p0Str = p0 == "System.String";
                    bool p1Str = p1 == "System.String";
                    bool p0Int = p0 == "System.Int32" || p0 == "System.UInt32" || p0 == "System.Int64" || p0 == "System.UInt64";
                    bool p1Int = p1 == "System.Int32" || p1 == "System.UInt32" || p1 == "System.Int64" || p1 == "System.UInt64";
                    if ((p0Str && p1Int) || (p1Str && p0Int))
                        yield return method;
                }
            }
        }

        private int DecryptStrings(ModuleDefMD module, List<MethodDef> candidates)
        {
            _loadedAssembly = Assembly.LoadFile(textBox1.Text);
            int replaced = 0;
            var delegateMap = BuildDelegateDecryptorMap(module);

            foreach (var type in module.GetTypes())
            {
                foreach (var method in type.Methods)
                {
                    if (!method.HasBody)
                        continue;
                    var instrs = method.Body.Instructions;
                    for (int i = 0; i < instrs.Count; i++)
                    {
                        var instr = instrs[i];
                        if (instr.OpCode != OpCodes.Call && instr.OpCode != OpCodes.Callvirt)
                            continue;
                        var called = instr.Operand as IMethod;
                        if (called == null)
                            continue;
                        var mdef = called.ResolveMethodDef();
                        int ldsfldIndex = -1;
                        // Suporte: delegate.Invoke como wrapper para decryptor
                        if (mdef != null && instr.OpCode == OpCodes.Callvirt && mdef.Name == "Invoke" && mdef.DeclaringType != null && IsDelegateType(mdef.DeclaringType))
                        {
                            // tenta localizar o campo delegate carregado pouco antes do callvirt
                            for (int back = 1; back <= 8 && i - back >= 0; back++)
                            {
                                var ins = instrs[i - back];
                                if (ins.OpCode == OpCodes.Ldsfld && ins.Operand is FieldDef f && delegateMap.TryGetValue(f, out var target))
                                {
                                    mdef = target;
                                    ldsfldIndex = i - back;
                                    break;
                                }
                            }
                        }
                        if (mdef == null)
                            continue;
                        if (!candidates.Contains(mdef))
                            continue;

                        if (TryGetArgs(instrs, i, out int ldstrIndex, out int ldcIndex, out string enc, out long key, out bool stringFirst))
                        {
                            var dec = InvokeDecryptor(mdef, enc, key, stringFirst);
                            if (dec != null)
                            {
                                instrs[ldstrIndex].OpCode = OpCodes.Ldstr;
                                instrs[ldstrIndex].Operand = dec;
                                // remover call e o inteiro, na ordem segura
                                int firstRemove = Math.Max(ldcIndex, i);
                                int secondRemove = Math.Min(ldcIndex, i);
                                instrs.RemoveAt(firstRemove);
                                instrs.RemoveAt(secondRemove);
                                if (ldsfldIndex >= 0)
                                {
                                    // remover o ldsfld do delegate
                                    instrs.RemoveAt(ldsfldIndex);
                                    // reajusta i se necessário
                                    if (ldsfldIndex < i) i--;
                                    if (ldsfldIndex < ldcIndex) { ldstrIndex--; }
                                }
                                replaced++;
                                i = Math.Max(ldstrIndex - 1, -1);
                            }
                        }
                    }
                }
            }
            return replaced;
        }

        private Dictionary<FieldDef, MethodDef> BuildDelegateDecryptorMap(ModuleDefMD module)
        {
            var map = new Dictionary<FieldDef, MethodDef>();
            foreach (var type in module.GetTypes())
            {
                // busca .cctor
                var cctor = type.FindStaticConstructor();
                if (cctor == null || !cctor.HasBody)
                    continue;
                var instrs = cctor.Body.Instructions;
                for (int i = 0; i < instrs.Count; i++)
                {
                    // padrão: ldnull/ldftn target; newobj delegate::.ctor(object,native int); stsfld field
                    if (instrs[i].OpCode == OpCodes.Ldftn && i + 2 < instrs.Count)
                    {
                        var target = instrs[i].Operand as IMethod;
                        var newobj = instrs[i + 1];
                        var st = instrs[i + 2];
                        if (newobj.OpCode == OpCodes.Newobj && st.OpCode == OpCodes.Stsfld)
                        {
                            var ctor = newobj.Operand as IMethod;
                            var field = st.Operand as FieldDef;
                            if (ctor != null && field != null && target != null)
                            {
                                // verifica se é delegate com assinatura desejada
                                var tdor = field.FieldType.ToTypeDefOrRef();
                                var delegateType = tdor != null ? tdor.ResolveTypeDef() : null;
                                if (delegateType != null)
                                {
                                    var invoke = delegateType.Methods.FirstOrDefault(m => m.Name == "Invoke");
                                    if (invoke != null && invoke.MethodSig.RetType.FullName == "System.String" && invoke.Parameters.Count == 2)
                                    {
                                        var p0 = invoke.Parameters[0].Type.FullName;
                                        var p1 = invoke.Parameters[1].Type.FullName;
                                        bool ok = (p0 == "System.String" && (p1 == "System.Int32" || p1 == "System.UInt32" || p1 == "System.Int64" || p1 == "System.UInt64")) ||
                                                  (p1 == "System.String" && (p0 == "System.Int32" || p0 == "System.UInt32" || p0 == "System.Int64" || p0 == "System.UInt64"));
                                        if (ok)
                                        {
                                            var targetDef = target.ResolveMethodDef();
                                            if (targetDef != null)
                                            {
                                                map[field] = targetDef;
                                            }
                                        }
                                    }
                                }
                            }
                            i += 2;
                        }
                    }
                }
            }
            return map;
        }

        private bool IsDelegateType(TypeDef type)
        {
            if (type == null) return false;
            var bt = type.BaseType;
            if (bt == null) return false;
            var name = bt.FullName;
            return name == "System.MulticastDelegate" || name == "System.Delegate";
        }

        private bool TryGetArgs(IList<Instruction> instrs, int callIndex, out int ldstrIndex, out int ldcIndex, out string value, out long key, out bool stringFirst)
        {
            ldstrIndex = -1;
            ldcIndex = -1;
            value = null;
            key = 0;
            stringFirst = true;

            int i1 = callIndex - 1;
            int i2 = callIndex - 2;
            if (i2 < 0)
                return false;

            var a = instrs[i2];
            var b = instrs[i1];

            if (a.OpCode == OpCodes.Ldstr && b.IsLdcI4())
            {
                ldstrIndex = i2;
                ldcIndex = i1;
                value = a.Operand as string;
                key = b.GetLdcI4Value();
                stringFirst = true;
                return true;
            }
            if (a.IsLdcI4() && b.OpCode == OpCodes.Ldstr)
            {
                ldstrIndex = i1;
                ldcIndex = i2;
                value = b.Operand as string;
                key = a.GetLdcI4Value();
                stringFirst = false;
                return true;
            }
            // fallback: procurar em janela pequena
            int window = 8;
            int foundStr = -1;
            int foundInt = -1;
            for (int k = 1; k <= window && callIndex - k >= 0; k++)
            {
                var ins = instrs[callIndex - k];
                if (foundStr == -1 && ins.OpCode == OpCodes.Ldstr)
                {
                    foundStr = callIndex - k;
                }
                if (foundInt == -1 && (ins.IsLdcI4() || ins.OpCode == OpCodes.Ldc_I8))
                {
                    foundInt = callIndex - k;
                }
                if (foundStr != -1 && foundInt != -1)
                    break;
            }
            if (foundStr != -1 && foundInt != -1)
            {
                ldstrIndex = foundStr;
                ldcIndex = foundInt;
                value = instrs[ldstrIndex].Operand as string;
                key = instrs[ldcIndex].OpCode == OpCodes.Ldc_I8 ? (long)(long)instrs[ldcIndex].Operand : instrs[ldcIndex].GetLdcI4Value();
                stringFirst = foundStr < foundInt; // ordem de push
                return true;
            }
            return false;
        }

        private string InvokeDecryptor(MethodDef methodDef, string enc, long key, bool stringFirst)
        {
            if (!_methodInfoCache.TryGetValue(methodDef, out var mi))
            {
                var declTypeFull = methodDef.DeclaringType.ReflectionFullName.Replace('/', '+');
                var type = _loadedAssembly.GetType(declTypeFull);
                if (type == null)
                    return null;
                // Monta a assinatura conforme parâmetros do método
                var p0 = methodDef.Parameters[0].Type.FullName;
                var p1 = methodDef.Parameters[1].Type.FullName;
                Type tInt0 = (p0 == "System.Int64" || p0 == "System.UInt64") ? typeof(long) : typeof(int);
                Type tInt1 = (p1 == "System.Int64" || p1 == "System.UInt64") ? typeof(long) : typeof(int);
                Type[] sig = p0 == "System.String" ? new Type[] { typeof(string), tInt1 } : new Type[] { tInt0, typeof(string) };
                mi = type.GetMethod(methodDef.Name,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static,
                    null,
                    sig,
                    null);
                if (mi == null)
                    return null;
                _methodInfoCache[methodDef] = mi;
            }
            object argInt = mi.GetParameters()[0].ParameterType == typeof(string) ? (mi.GetParameters()[1].ParameterType == typeof(long) ? (object)key : (object)(int)key) : (mi.GetParameters()[0].ParameterType == typeof(long) ? (object)key : (object)(int)key);
            object[] args = stringFirst ? new object[] { enc, argInt } : new object[] { argInt, enc };
            var result = mi.Invoke(null, args);
            return result as string;
        }

        private void SanitizeIdentifiers(ModuleDefMD module)
        {
            foreach (var type in module.GetTypes())
            {
                // Tipo e namespace
                type.Namespace = SanitizeNamespace(type.Namespace);
                {
                    string desired = SanitizeSimple(type.Name, allowDot: false);
                    if (!IsReadableName(desired))
                        desired = type.DeclaringType == null ? "Type" : "NestedType";
                    type.Name = EnsureUnique(type.DeclaringType == null ? type.Module.Types.Select(t => t.Name.String) : type.DeclaringType.NestedTypes.Select(t => t.Name.String), desired);
                }

                // Campos
                var usedFieldNames = new HashSet<string>(type.Fields.Select(f => f.Name.String));
                int fieldCounter = 1;
                foreach (var field in type.Fields)
                {
                    string safe = SanitizeSimple(field.Name, allowDot: false);
                    if (!IsReadableName(safe))
                        safe = $"field{fieldCounter++}";
                    if (safe != field.Name)
                    {
                        safe = EnsureUnique(usedFieldNames, safe);
                        usedFieldNames.Remove(field.Name);
                        field.Name = safe;
                        usedFieldNames.Add(field.Name);
                    }
                }

                // Métodos (evitar renomear especiais/acessores)
                var usedMethodNames = new HashSet<string>(type.Methods.Select(m => m.Name.String));
                int methodCounter = 1;
                foreach (var m in type.Methods)
                {
                    if (m.IsConstructor || m.IsStaticConstructor || m.IsSpecialName)
                        continue;
                    string safe = SanitizeSimple(m.Name, allowDot: false);
                    if (!IsReadableName(safe))
                        safe = $"Method{methodCounter++}";
                    if (safe != m.Name)
                    {
                        safe = EnsureUnique(usedMethodNames, safe);
                        usedMethodNames.Remove(m.Name);
                        m.Name = safe;
                        usedMethodNames.Add(m.Name);
                    }

                    // Parâmetros
                    for (int i = 0; i < m.Parameters.Count; i++)
                    {
                        var p = m.Parameters[i];
                        if (p.IsHiddenThisParameter)
                            continue;
                        string pname = string.IsNullOrEmpty(p.Name) ? $"param{i + 1}" : p.Name;
                        string psafe = SanitizeSimple(pname, allowDot: false);
                        if (!IsReadableName(psafe))
                            psafe = $"param{i + 1}";
                        if (psafe != p.Name)
                            p.Name = psafe;
                    }

                    // Variáveis locais
                    if (m.HasBody && m.Body.HasVariables)
                    {
                        var usedLocalNames = new HashSet<string>(m.Body.Variables.Where(v => !string.IsNullOrEmpty(v.Name)).Select(v => v.Name));
                        for (int li = 0; li < m.Body.Variables.Count; li++)
                        {
                            var local = m.Body.Variables[li];
                            string lname = string.IsNullOrEmpty(local.Name) ? $"local{li + 1}" : local.Name;
                            string lsafe = SanitizeSimple(lname, allowDot: false);
                            if (!IsReadableName(lsafe))
                                lsafe = $"local{li + 1}";
                            if (lsafe != local.Name)
                            {
                                lsafe = EnsureUnique(usedLocalNames, lsafe);
                                if (!string.IsNullOrEmpty(local.Name)) usedLocalNames.Remove(local.Name);
                                local.Name = lsafe;
                                usedLocalNames.Add(local.Name);
                            }
                        }
                    }
                }

                // Propriedades
                var usedPropNames = new HashSet<string>(type.Properties.Select(pr => pr.Name.String));
                int propCounter = 1;
                foreach (var pr in type.Properties)
                {
                    string safe = SanitizeSimple(pr.Name, allowDot: false);
                    if (!IsReadableName(safe))
                        safe = $"Property{propCounter++}";
                    if (safe != pr.Name)
                    {
                        safe = EnsureUnique(usedPropNames, safe);
                        usedPropNames.Remove(pr.Name);
                        pr.Name = safe;
                        usedPropNames.Add(pr.Name);
                    }
                }

                // Eventos
                var usedEvtNames = new HashSet<string>(type.Events.Select(ev => ev.Name.String));
                int eventCounter = 1;
                foreach (var ev in type.Events)
                {
                    string safe = SanitizeSimple(ev.Name, allowDot: false);
                    if (!IsReadableName(safe))
                        safe = $"Event{eventCounter++}";
                    if (safe != ev.Name)
                    {
                        safe = EnsureUnique(usedEvtNames, safe);
                        usedEvtNames.Remove(ev.Name);
                        ev.Name = safe;
                        usedEvtNames.Add(ev.Name);
                    }
                }
            }
        }

        private string SanitizeNamespace(string ns)
        {
            if (string.IsNullOrEmpty(ns)) return ns;
            var sb = new StringBuilder(ns.Length);
            foreach (var ch in ns)
            {
                if (char.IsLetterOrDigit(ch) || ch == '_' || ch == '.')
                    sb.Append(ch);
                else
                    sb.Append('_');
            }
            // colapsa múltiplos underscores e remove underscores nas extremidades
            string result = CollapseUnderscores(sb.ToString());
            if (result.StartsWith(".")) result = "N" + result;
            if (!IsReadableName(result)) result = "Namespace";
            return result;
        }

        private string SanitizeSimple(string name, bool allowDot)
        {
            if (string.IsNullOrEmpty(name)) return "Renamed";
            var sb = new StringBuilder(name.Length);
            foreach (var ch in name)
            {
                if (char.IsLetterOrDigit(ch) || ch == '_' || (allowDot && ch == '.'))
                    sb.Append(ch);
                else
                    sb.Append('_');
            }
            string s = CollapseUnderscores(sb.ToString());
            if (!string.IsNullOrEmpty(s) && char.IsDigit(s[0]))
                s = "N" + s;
            return s.Length == 0 ? "Renamed" : s;
        }

        private string EnsureUnique(IEnumerable<string> existing, string desired)
        {
            var set = existing is HashSet<string> hs ? hs : new HashSet<string>(existing);
            if (!set.Contains(desired)) return desired;
            int i = 1;
            string candidate;
            do { candidate = desired + "_" + i++; } while (set.Contains(candidate));
            return candidate;
        }

        private string EnsureUnique(HashSet<string> set, string desired)
        {
            if (!set.Contains(desired)) return desired;
            int i = 1;
            string candidate;
            do { candidate = desired + "_" + i++; } while (set.Contains(candidate));
            return candidate;
        }

        private bool IsReadableName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            // remove underscores para avaliação de conteúdo
            string trimmed = name.Trim('_');
            if (trimmed.Length == 0) return false;
            if (name.Length < 3) return false;

            int letterCount = 0;
            int digitCount = 0;
            foreach (var c in name)
            {
                if (char.IsLetter(c)) letterCount++;
                else if (char.IsDigit(c)) digitCount++;
            }
            if (letterCount == 0) return false;

            // Evita padrões ambíguos do tipo "a1", "b2", etc.
            if (name.Length <= 3 && letterCount == 1 && digitCount >= 1) return false;
            return true;
        }

        private string CollapseUnderscores(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            var sb = new StringBuilder(s.Length);
            bool lastWasUnderscore = false;
            foreach (var ch in s)
            {
                if (ch == '_')
                {
                    if (!lastWasUnderscore)
                    {
                        sb.Append(ch);
                        lastWasUnderscore = true;
                    }
                }
                else
                {
                    sb.Append(ch);
                    lastWasUnderscore = false;
                }
            }
            // remove underscores nas extremidades
            int start = 0;
            int end = sb.Length - 1;
            while (start <= end && sb[start] == '_') start++;
            while (end >= start && sb[end] == '_') end--;
            return start > end ? string.Empty : sb.ToString(start, end - start + 1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Browse for target assembly";
            openFileDialog.InitialDirectory = "c:\\";
            if (DirectoryName != "")
            {
                openFileDialog.InitialDirectory = this.DirectoryName;
            }
            openFileDialog.Filter = "All files (*.exe,*.dll)|*.exe;*.dll";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog.FileName;
                textBox1.Text = fileName;
                int num = fileName.LastIndexOf("\\", StringComparison.Ordinal);
                if (num != -1)
                {
                    DirectoryName = fileName.Remove(num, fileName.Length - num);
                }
                if (DirectoryName.Length == 2)
                {
                    DirectoryName += "\\";
                }
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }

    #endregion



}
